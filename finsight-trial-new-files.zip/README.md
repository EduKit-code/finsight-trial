# FinSight Trial (Vercel Preview)
File baru di paket ini: assets/ledger.js, assets/tracker.js, assets/ext.css, index.html, test/ledger.test.js.
File lama yang TIDAK ikut (ada di deployment dpl_Hp6UXv… / dpl_3KNmqc…): assets/app.js, assets/domain.js, assets/store.js,
assets/app.css, assets/engine/FinSightVNextEngine.js, vercel.json. Ambil dari Vercel sebelum membuat repo.
Tes: cd test && node ledger.test.js  (memakai salinan subset engine/domain, bukan file deploy)
